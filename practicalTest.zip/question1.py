import numpy as np
import cv2

images = []
hsl = []
for i in range(10):
    name = "redeye"+str(i+1)+".jpg"  #pic and .py under the same file
    images.append(cv2.imread(name))

    H = images[i].shape[0]
    W = images[i].shape[1]

    if (W > 500):  #in case the image is too big and the screen cant show
        images[i] = cv2.resize(images[i], (int(W * 0.5), int(H * 0.5)))

    hsl.append(cv2.cvtColor(images[i], cv2.COLOR_BGR2HLS))
    for m in range(0, images[i].shape[0]) :
        for n in range(0, images[i].shape[1]):
            (H, L, S) = hsl[i][m, n]
            LS_ratio = L / S
            eye_pixel =(L >= 64) and (S >= 100) and(LS_ratio > 0.5) \
                       and (LS_ratio < 1.5) and((H <= 7)or (H >= 162))
            if eye_pixel:
                hsl[i][m, n] = (255, 255, 255)
            else:
                hsl[i][m, n] = (0, 0, 0)

    cv2.imshow("image"+str(i+1), np.hstack([images[i], hsl[i]]))

    cv2.waitKey(0)
    cv2.destroyAllWindows()
