import numpy as np
import cv2

images = []
greyscaleCV = []
greyscaleManual = []
for i in range(3):
    name = ["Q3a.jpg", "Q3b.jpg", "Q3c.jpg"]
    images.append(cv2.imread(name[i]))
    greyscaleCV.append(cv2.cvtColor(images[i], cv2.COLOR_BGR2GRAY))
    H = images[i].shape[0]
    W = images[i].shape[1]
    gray = np.zeros((H, W), np.uint8)
    for m in range(0, H) :
        for n in range(0, W):
            gray[m, n] = np.clip(0.114 * images[i][m, n, 0] + 0.299 * images[i][m, n, 1] + 0.587 * images[i][m, n, 2], 0, 255)

    greyscaleManual.append(gray)
    cv2.imshow("original", images[i])
    cv2.imshow("grayCV", greyscaleCV[i])
    cv2.imshow("gray", greyscaleManual[i])
    cv2.waitKey(0)
    cv2.destroyAllWindows()
