import numpy as np
import cv2

images = []
blur1 = []
blur2 = []
blur3 = []
def redeye(hsl):
    for m in range(0, hsl.shape[0]) :   #dealing pixel by pixel
        for n in range(0, hsl.shape[1]):
            (H, L, S) = hsl[m, n]
            print(hsl[m,n])
            LS_ratio = L / S
            eye_pixel =(L >= 64) and (S >= 100) and(LS_ratio > 0.5) \
                       and (LS_ratio < 1.5) and((H <= 7)or (H >= 162))
            if eye_pixel:
                hsl[m, n] = (255, 255, 255)    #white
            else:
                hsl[m, n] = (0, 0, 0)      #black

for i in range(10):
    name = "redeye"+str(i+1)+".jpg"
    images.append(cv2.imread(name))
    H = images[i].shape[0]
    W = images[i].shape[1]

    if(W > 500):   #in case the image is too big and the screen cant show
        images[i] = cv2.resize(images[i], (int(W*0.5), int(H*0.5)))

    blur1.append(cv2.cvtColor(cv2.bilateralFilter(images[i], 5, 21, 21), cv2.COLOR_BGR2HLS))
    blur2.append(cv2.cvtColor(cv2.bilateralFilter(images[i], 7, 31, 31), cv2.COLOR_BGR2HLS))
    blur3.append(cv2.cvtColor(cv2.bilateralFilter(images[i], 9, 41, 41), cv2.COLOR_BGR2HLS))

    redeye(blur1[i])
    redeye(blur2[i])
    redeye(blur3[i])

    cv2.imshow("image"+str(i+1), np.hstack([images[i], blur1[i], blur2[i], blur3[i]]))

    cv2.waitKey(0)
    cv2.destroyAllWindows()
